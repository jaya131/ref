import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Switch, Route, Redirect, Link } from "react-router-dom";
import { createBrowserHistory } from 'history';
import Login from './components/Login/Login';
import Operator from './components/Operator/Operator';
import Manager from './components/Manager/Manager';
import Admin from "./components/Admin/Admin";
import OperatorLanding from './components/Operator/Operatorlanding';
import OperatorValidate from './components/Operator/Operatorvalidate';


const App = () => (
  <Router history={createBrowserHistory}>

 

    <Switch>

    {/* <Route path="/">

            <Login />

          </Route>

          <Route path="/manager">

            <Manager />

          </Route> */}

          <Route exact path='/' component={Login} />

          <Route  path='/manager' component={Manager} />

          {/* <Route exact path="/operator" component={Operator}>

          <Redirect to="/operator/operatorlanding" />

        </Route> */}

          <Route  path='/operator' component={Operator} >

          {/* <Redirect exact from="/operator" to="/operator/operatorlanding" /> */}

            </Route>

          <Route  path='/admin' component={Admin} />

         

          {/* <Redirect  from="/operator" to="/operatorlanding" />

          <Route path = "/operatorlanding" component = {OperatorLanding}></Route>

          <Route path = "/operatorvalidate" component = {OperatorValidate}></Route> */}

          {/* <Route path="/Operator">

            <Operator />
            

          </Route> */}

   

    </Switch>

  </Router>
  
);

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);

export default App;