import React, {useState, useEffect} from 'react';
import Accordion from 'react-bootstrap/Accordion';
import logo from './logo.png';
import logoexl from './exl-logo.png';
import { Button, Collapse } from 'react-bootstrap'; 
import { BrowserRouter as Router, Route, Redirect, Switch, Link } from 'react-router-dom';
import {getToken, getUser, removedUserSession, setUserSession} from "../Utils/common"; 





const resetpassword = (props) => {


    return(
		
		<div className="background">
			<nav className="bg-nav">
				<div className="row col-12 d-flex justify-content-center text-white">
					<div className="col-md-3 col-xs-9"><img className="logo-inner" src={logo}/></div>
					<div className="col-md-8">&nbsp;</div>
					<div className="col-md-1 col-xs-3"><img className="logo-exl" src={logoexl}/></div>					
				</div>
			</nav>
			<div className="section-code">
			<div className="row">
				<div className="col-md-12">
					<h1>Reset Password!  </h1>
				</div> 
			</div>
			
				
				
					
			
			</div>			
		</div>
		
    )
}
export default resetpassword;