import React, { useCallback, useMemo} from 'react';
import { forwardRef, useState, useImperativeHandle, useRef } from "react";
import { render } from 'react-dom';
import { AgGridReact } from 'ag-grid-react';
import  { getUserSession } from '../Utils/common';
import { Link } from 'react-router-dom'

import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';

const Table = forwardRef(({onSelectRow}, ref) => {
  const gridRef = useRef();
  const containerStyle = useMemo(() => ({ width: '100%', height: '100%' }), []);
  const gridStyle = useMemo(() => ({ height: '500px', overflowy:'scroll', width: '100%' }), []);
  const [rowData, setRowData] = useState();
  const [selectedFiles, setSelectedFiles] = useState([]);
  var defaultFilterParams = { readOnly: true };

  useImperativeHandle(ref, () => ({
    onGridReady, filterColumn, clearColumnFilter
  }));

  const LinkCellRenderer = (params) => (
    // <Link to={"/edit/" + params.data.id}>Edit</Link>
    <Link to={{ pathname: `/Manager/Managervalidate`, state: { file: params.data.case_id} }}>{params.data.case_id}</Link>
    );



  const [columnDefs, setColumnDefs] = useState([
    
    { headerName: 'CASE ID', field: 'case_id', hide: false , 
    cellRenderer: LinkCellRenderer,      
    headerCheckboxSelection: true,
    headerCheckboxSelectionFilteredOnly: true,
    checkboxSelection: true, filter: 'agTextColumnFilter' ,
    filterParams: defaultFilterParams,
    // , cellRendererParams: { checkbox:true},
    resizable: true,
    width: 250
  },
  {  headerName: 'LOB', field: 'lob', hide: false , filter: 'agTextColumnFilter' , filterParams: {
    applyMiniFilterWhileTyping: true, defaultFilterParams
  }, sortable:true},
  //  { headerName: 'CASE ID', field: 'case_id', hide: false },
    {  headerName: 'CREATION DATE', field: 'creation_date', hide: false , filter: 'agTextColumnFilter',filterParams: {
      applyMiniFilterWhileTyping: true,defaultFilterParams
    }, sortable:true},
    {  headerName: 'STATUS', field: 'status', hide: false , filter: 'agTextColumnFilter' , filterParams: {
      defaultOption: "startsWith",
      applyMiniFilterWhileTyping: true,defaultFilterParams
    }, sortable:true},
    {  headerName: 'ASSIGNED TO', field: 'assigned_to', hide: false , filter: 'agTextColumnFilter' , supressMenu:true, filterParams: {
      applyMiniFilterWhileTyping: true,defaultFilterParams
    }, sortable:true},
    {  headerName: 'PRIORITY', field: 'priority', hide: false , filter: 'agTextColumnFilter' , supressMenu:true, filterParams: {
      applyMiniFilterWhileTyping: true,defaultFilterParams
    }, sortable:true},
    {  headerName: 'ASSIGNED ON', field: 'assigned_date', hide: false , filter: 'agTextColumnFilter' , supressMenu:true, filterParams: {
      applyMiniFilterWhileTyping: true,defaultFilterParams
    }, sortable:true},
    {  headerName: 'ID', field: 'id', hide: true}
  ]);
  const defaultColDef = useMemo(() => {
    return {
      flex: 1,
      minWidth: 100,
      floatingFilter: true,
      filter: true
    };
  }, []);
  const autoGroupColumnDef = useMemo(() => {
    
    return {
      headerName: 'ID',
      field: 'id',

      minWidth: 250,
      cellRenderer: 'agGroupCellRenderer',
      cellRendererParams: {
        checkbox: true,
      },
    };
  }, []);


  
  const clearColumnFilter = useCallback(() => {
    console.log("filter unassigned");

    // unfilter all rows
    let columns  = ["lob", "creation_date", "status", "assigned_to", "priority", "assigned_date"];

    for (let i = 0; i<columns.length; i++) {
      var statusFilter = gridRef.current.api.getFilterInstance(
        columns[i]
      );
      statusFilter.setModel({
        filterType: "text",
        type: "startsWith",
        filter: ""
      });
      gridRef.current.api.onFilterChanged();
    }
  });


  const filterColumn = useCallback((column, value) => {
    

		var statusFilter = gridRef.current.api.getFilterInstance(
		  column
		);
		statusFilter.setModel({
      filterType: "text",
      type: "startsWith",
      filter: value
    });
    gridRef.current.api.onFilterChanged();
    gridRef.current.api.redrawRows();
    // statusFilter.setModel({ values: "Unassigned"}).then(function() { gridRef.current.api.onFilterChanged(); });
		
	  }, []);


  const onGridReady = useCallback((params) => {
    fetch(process.env.REACT_APP_API_URL+"/api/file/", {
      method: "GET",
      mode: "cors",
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
         "Access-Control-Allow-Headers": "*",
         "Access-Control-Allow-Methods": "*",
        "Access-Control-Expose-Headers": "*",
        "Access-Control-Allow-Credentials": false,
        "Authorization": "Bearer " + getUserSession()
      }
    }).then((resp) => resp.json())
      .then(data => {
        
    
          console.log("response in table data")
          console.log(data)
          let row_data = [];
          row_data = data.data.map((file) => {
            let assigned_operator = "";
            let lob = "";
            let priority = "";
            if (file.lob.lob_name.toLowerCase() == "rcs"){
              lob = file.lob.lob_name.toUpperCase();
            } else {
              lob = file.lob.lob_name;
            }

            if (file.assigned_to != null) {
               assigned_operator = file.assigned_to.first_name
            } 
            if (file.is_on_priority) {
              priority = "Rush";
            } else {
              priority = "Normal";
            }
            return {
            id: file.id,
            case_id: file.case_id,
            status: file.status,
            assigned_to: assigned_operator,
            creation_date: file.creation_date,
            lob: lob,
            priority: priority,
            assigned_date: file.assigned_date
            }

          });
          console.log(row_data)
          setRowData(row_data);
          document.getElementById('Unassigned').click()
          var defaultSortModel = [
            { colId: 'priority', sort: 'desc', sortIndex: 0 },
            
          ];
          params.columnApi.applyColumnState({ state: defaultSortModel });
        
          gridRef.current.api.sizeColumnsToFit();
          
      }).catch(error => {
        console.log("catch")
        console.log(error)
        // setLoading(false);
        // if (error.response.status === 401 || error.response.status === 400) {
        //   setError(error.response.data.message);
        // }
        // else {
        //   setError("error message");
        // }
      });
    });

    const onQuickFilterChanged = useCallback(() => {
      gridRef.current.api.setQuickFilter(
        document.getElementById('quickFilter').value
      );
    }, []);

    const onSelectionChanged = useCallback((event) => {
      let temp = []
      
      for (let i = 0; i < event.api.getSelectedNodes().length; i++) {
        temp.push(event.api.getSelectedNodes()[i].data);
      }
      onSelectRow(temp);
      //console.log(temp)
     //onsole.log(selectedFiles)
    }, [onSelectRow]);


    return (
    <div style={containerStyle}>
      <div className="example-wrapper">
        <div className="quick-filter" style={{ marginBottom: '5px' }}>
          <input
            type="text"
            onInput={onQuickFilterChanged}
            id="quickFilter"
            placeholder="Quick filter"
          />
        </div>

        <div style={gridStyle} className="ag-theme-alpine">
          <AgGridReact
          frameworkComponents={{
            LinkCellRenderer
          }}
            ref={gridRef}
            rowData={rowData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            suppressRowClickSelection={true}
            onGridReady={onGridReady}
            onSelectionChanged={onSelectionChanged}
            rowSelection={'multiple'}
            enableCellTextSelection= {true}
            pagination={true}
            multiSortKey={'ctrl'}
            paginationPageSize={10}
          ></AgGridReact>
        </div>
      </div>
    </div>
  );
});

export default Table;