import React, { useEffect, useCallback } from 'react';
import { forwardRef, useState,  useRef } from "react";
import { Modal, Button } from 'react-bootstrap';
import notstarted from '../../images/notstarted.png';
import processing from '../../images/processing.png';
import review from '../../images/review.png';
import claim from '../../images/claim.png';
import priority from '../../images/priority.png';
import Table from './table';
import { getToken, getUser, removedUserSession, showToaster, getUserSession } from "../Utils/common";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';
import { transform } from 'typescript';



const Managerlanding = (props) => {
	const childRef = useRef(null);

	const [open, setOpen] = useState(false);
	//let user = getUser();
	const [user, setUser] = useState(getUser());
	const [show, setShow] = useState(false);
	const handleClose = () => setShow(false);
	const handleShow = () => setShow(true);
	const [selectedFiles, setSelectedFiles] = useState([]);
	const handleLogout = () => {
		removedUserSession();
		props.history.push('/');
	}
	const [unassigned, setUnassigned] = useState('');
	const [assigned, setAssigned] = useState('');
	const [sent_for_review, setSent_for_review] = useState('');
	const [priority_claims, setPriority_claims] = useState('');
	const [error_claims, setError_claims] = useState('');
	const [error, setError] = useState(null);
	const [loading, setLoading] = useState(false);
	const [userId, setUserId] = useState('');


	let [users, setUsers] = useState([]);
	const currentUser = ((selectedUser) => {
		//debugger
		for (let i = 0; i < users.length; i++)
			setUserId(selectedUser)
		
	
	});
	
	async function fetchUser() {
		console.log("inside user effect")
		const response = await fetch("http://10.146.225.68:8181/api/users/", {
			method: "GET",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Headers": "*",
				"Access-Control-Allow-Methods": "*",
				"Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false,
				"Authorization": "Bearer " + getUserSession()
			}
		}).then(response => response.json())
			.then(data => {

				console.log("response in get data")
				console.log(data)
				//users = data.data;
				setUsers(data.data)
				setLoading(false);



			}).catch(error => {
				console.log("catch")
				console.log(error)
				setLoading(false);
				if (error.response.status === 401 || error.response.status === 400) {
					setError(error.response.data.message);
				}
				else {
					setError("error message");
				}
			});
	}

	useEffect(() => {
		fetchUser();
	}, []);


	async function fetchData() {
		console.log(getUserSession())
		const response = await fetch("http://10.146.225.68:8181/api/files_status/", {
			method: "GET",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Headers": "*",
				"Access-Control-Allow-Methods": "*",
				"Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false,
				"Authorization": "Bearer " + getUserSession()
			}
		}).then(response => response.json())
			.then(data => {
				setUnassigned(data.data.unassigned)
				setAssigned(data.data.assigned)
				setSent_for_review(data.data.sent_for_review)
				setPriority_claims(data.data.priority_claims)
				setError_claims(data.data.error_claims)


			}).catch(error => {
				console.log("catch")
				console.log(error)
				setLoading(false);
				if (error.response.status === 401 || error.response.status === 400) {
					setError(error.response.data.message);
				}
				else {
					setError("error message");
				}
			});


	}
	useEffect(() => {
		fetchData();
	}, []);

	


	const selectRow = (files) => {
		setSelectedFiles(files);
		console.log(files);
		console.log(selectedFiles);
	}

	const filterUnassigned = useCallback(() => {
		childRef.current.clearColumnFilter();
		childRef.current.filterColumn("status", "Unassigned");
	  }, []);

	const filterPriority = useCallback(() => {
		childRef.current.clearColumnFilter();
	childRef.current.filterColumn("priority", "Rush");
	}, []);

	const filterAssigned = useCallback(() => {
		childRef.current.clearColumnFilter();
		childRef.current.filterColumn("status", "Assigned");
	  }, []);

	  const filterReview = useCallback(() => {
		childRef.current.clearColumnFilter();
		childRef.current.filterColumn("status", "Review");
	  }, []);
	  
	  const userChanged = (event) => {
		
		
		if (selectedFiles.length < 1 ) {
			showToaster("Please select at least 1 file to assign", "info");
			return
		}
		currentUser(event.target.value);
		handleShow();
	}

	const noClicked = () => {
		currentUser("");
		
		handleClose();
	}


	const handleAssign = async () => {
		console.log(selectedFiles);
		let data = []
		if (userId == "") {
			showToaster("Please select a user", "info");
			return
		}
		if (selectedFiles.length < 1 ) {
			showToaster("Please select at least 1 file to assign", "info");
			return
		}
		

		for (let i = 0; i < selectedFiles.length; i++) {
			data.push({ case_id: selectedFiles[i].id, assign_to: parseInt(userId) })
		}
		const body = {
			data: data
		}
		const response = await fetch("http://10.146.225.68:8181/api/file_assigning/", {
			method: "POST",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Headers": "*",
				"Access-Control-Allow-Methods": "*",
				"Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false,
				"Authorization": "Bearer " + getUserSession()
			},
			body: JSON.stringify(body)
		}).then(response => response.json())
			.then(data => {
				console.log(data);
				noClicked();
				childRef.current.onGridReady();
				if (data.error == true) {
					showToaster(data.message, 'error')
				}
				else {
					// setSuccessMessage(data.message)
					showToaster(data.message, 'success');
					handleClose();

				}
				handleClose();
				fetchData();

				//}

			}).catch(error => {
				console.log("catch")
				console.log(error)
				setLoading(false);
				handleClose();
				showToaster('Something went wrong. Error in assigning', 'error')

			});


	}


	return (
		  
		<div class="background  mgr-dashboard">
			{/* <nav className=" bg-nav">
				<div className="row col-12 d-flex justify-content-center text-white">
					<div className="col-md-3 col-xs-9"><img className="logo-inner" src={logo} /></div>
					<div className="col-md-8">&nbsp;</div>
					<div className="col-md-1 col-xs-3"><img className="logo-exl" src={logoexl} /></div>
				</div>
			</nav> */}
			<div className="section-code">
				<h1>Welcome {user}! <a href="" type="link" className="logout" onClick={handleLogout}>Logout</a></h1>
				<div className="col-md-12">
					<div className="row no-padding " >
					
						<div className="col-md-2 d-flex no-padding mgr-right"><button className="mgr" id="Unassigned" onClick={filterUnassigned}><div className=" text-black spacer font-box box-tab"><img src={notstarted} alt="" /><div className='case-number'>{unassigned}</div><br />Un-assigned
						</div></button></div>
						
						
						<div className="col-md-2 d-flex no-padding mgr-right"><button className="mgr" onClick={filterAssigned}><div className=" text-black spacer font-box box-tab"><img src={processing} className="margin-top" alt="" /><div className='case-number'>{assigned}</div><br />Assigned </div></button></div>
						
						
						<div className="col-md-2 d-flex no-padding mgr-right"><button className="mgr" onClick={filterPriority}><div className=" text-black spacer font-box box-tab"><img src={priority} alt="" /><div className='case-number'>{priority_claims}</div><br />Priority Claims</div></button></div>
						
						
						
						<div className="col-md-2 d-flex no-padding mgr-right"><button className="mgr" onClick={filterReview}><div className=" text-black spacer font-box box-tab"><img src={review} alt="" /><div className='case-number'>{sent_for_review}</div><br />Review Claims</div></button></div>
						
						
						<div className="col-md-2 d-flex no-padding"><button className="mgr"><div className=" text-black spacer font-box box-tab no-mgr-right" ><img src={claim} alt="" /><div className='case-number'>{error_claims}</div><br />Claims in Progress
</div></button></div>
					</div>
				</div>
				<div className="col-md-12 row d-flex">
					<div className="white-bg">
						<div className="row form-group">
							<div className=" col-md-6  d-flex py-2">
								<div className="col-md-2 d-flex">
									<h2 className='padding-top'>Assign to</h2>
								</div>
								<div className="col-md-6 d-flex">
									<div className="col-md-12">
										{/* <select class="form-select" value={userId} id="myselect" onChange={e => currentUser(e.target.value)}> */}
										<select class="form-select" value={userId} id="myselect" onChange={event => userChanged(event)}>
											<option > Select user</option>
											{users.map((user) => (
												<option value={user.id} >
													{  user.first_name  }
													
												</option>
											))}
										</select>
									
									</div>
									<Modal show={show} onHide={handleClose}>
				<Modal.Header closeButton>
					Assign claim
				</Modal.Header>
				<Modal.Body> You want to assign claim?&nbsp;&nbsp; <Button variant="warning" onClick={handleAssign}>
						Yes
					</Button> &nbsp; &nbsp;
					<Button variant="outline-warning" onClick={noClicked}>
						No
					</Button> </Modal.Body>
				
			</Modal>
								</div>
							</div>
							{/* <div className="offset-md-5 col-md-1  d-flex">
								<input type="button" href="" className="float-right btn btn-warning" value="Assign" onClick={handleAssign} />
							</div> */}
						</div>
						<Table onSelectRow={selectRow} ref={childRef} />

					</div>
					<div class="clear"></div>
				</div>
			</div>
			
								
					


								
			
			<ToastContainer
				position="top-right"
				autoClose={5000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
				theme='colored'
			/>
		</div>
		  
	)
}
export default Managerlanding;