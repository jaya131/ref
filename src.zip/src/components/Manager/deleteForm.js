import $ from 'jquery/src/jquery';


const deleteForm = (extracted_json) => {
    // If absolute URL from the remote server is provided, configure the CORS
    // header on that server.
    var jQueryScript = document.createElement('script');
    jQueryScript.setAttribute('src', 'https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js');
    document.head.appendChild(jQueryScript);

    $(document).ready(function () {
        var form_count = 0;
        while (true) {
            form_count = form_count + 1;
            if (("form" + form_count) in extracted_json) {
                if (form_count != 0) {
                    // document.getElementById("delete_" + form_count).click();
                    
                        
                            console.log("delete form")
                            //alert("Focused Elem_id = "+ this.id )
            
                            
                            var focus_id = "delete_" + form_count;
                            var matches = focus_id.split("_");
                            if (matches.length > 0) {
                                var deleteKey = matches[0]
                                if (deleteKey == "delete") {
                                    $(document.getElementById("delete_") + form_count).closest(".form").remove();
                                    //$("#l1 li").eq(matches[1]-1).remove();
                                    //alert(matches[1]);
            
                                }
            
                            }
            

                }

            } else {
                form_count = form_count - 1;
                break;
            }
        }


        // for (var count = 0; count <= form_count; count++) {
        //     document.getElementById("pay_stamp" + count).value = default_json['form' +count].pay_stamp
        //         document.getElementById("paykind_code" + count).value = default_json['form' +count].paykind_code
        //         document.getElementById("valid" + count).value = default_json['form' +count].valid
        //         document.getElementById("sub" + count).value = default_json['form' +count].sub
        //         document.getElementById("servicestate" + count).value = default_json['form' +count].servicestate
        //         document.getElementById("claimnumber" + count).value = default_json['form' +count].claimnumber
        //         document.getElementById("firstname" + count).value = default_json['form' +count].firstname
        //         document.getElementById("specialinstructions" + count).value = default_json['form' +count].specialinstructions
        //         document.getElementById("payableamount" + count).value = default_json['form' +count].payableamount
        //         document.getElementById("dateofservice1" + count).value = default_json['form' +count].dateofservice1
        //         document.getElementById("dateofservice2" + count).value = default_json['form' +count].dateofservice2
        //         document.getElementById("taxid" + count).value = default_json['form' +count].taxid
        //         document.getElementById("payeename" + count).value = default_json['form' +count].payeename
        //         document.getElementById("address1" + count).value = default_json['form' +count].address1
        //         document.getElementById("address2" + count).value = default_json['form' +count].address2
        //         document.getElementById("cityname" + count).value = default_json['form' +count].cityname
        //         document.getElementById("zipcode" + count).value = default_json['form' +count].zipcode
        //         document.getElementById("state" + count).value = default_json['form' +count].state
        // }
        // document.getElementById("pay_stamp0").focus();

    });
}


export default deleteForm;
