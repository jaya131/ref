
import React, { useState, useEffect, useRef } from 'react';
import $ from 'jquery/src/jquery';


const pdfFunction = (converted_doc, original_doc) => {
    // If absolute URL from the remote server is provided, configure the CORS
    // header on that server.
    var jQueryScript = document.createElement('script');
    jQueryScript.setAttribute('src', 'https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js');
    document.head.appendChild(jQueryScript);
    
    

    $(document).ready(function () {
        var original_doc_url = original_doc
        var converted_doc_url = converted_doc

        $("#pdfcontainer").hide();
        var url = converted_doc
        // "{% static 'test1.pdf' %}";

        // Loaded via <script> tag, create shortcut to access PDF.js exports.
        var pdfjsLib = null;
        //window['pdfjs-dist/build/pdf'];

        // The workerSrc property shall be specified.
        // pdfjsLib.GlobalWorkerOptions.workerSrc = '//mozilla.github.io/pdf.js/build/pdf.worker.js';

        var pdfDoc = null,
            pageRendering = false,
            pageNumPending = null,
            //scale = 0.8,
            scale = 0;

        var lastFocus = "";
       
        var currentFocus = "";
        pdfjsLib = window['pdfjs-dist/build/pdf'];
        pdfjsLib.GlobalWorkerOptions.workerSrc = '//mozilla.github.io/pdf.js/build/pdf.worker.js';
        let canvas = document.getElementById('the-canvas');
        let ctx = canvas.getContext('2d');
        let pageNum = 1;

function changeSpanWidth() {
    var spans = document.getElementById('textLayer').getElementsByTagName('span');
    console.log(spans);
    for (var i = 0; i< spans.length; i++) {
        var transformStyle = (spans[i].style.transform);
        var scaleX = parseFloat(transformStyle.replace(/[^\d.]/g, ''));
        var newScale = scaleX + 0.15;
        var spanLeft = parseFloat(spans[i].style.left);
        var newSpanLeft = spanLeft - 0.9;
        spans[i].style.left = newSpanLeft +"px";
        spans[i].style.transform = 'scaleX(' + newScale + ')';
    }
}

        function getdoc(url) {
            if (url && url != "None") {
                //bject.prototype.toString.call(url)
                $("#pdfcontainer").show();
                
                //alert(url);

            } else {
                $("#pdfcontainer").hide();
                return;
            }


            pageRendering = false;
            pageNumPending = null;
            scale = 1.2;



            //url = "{% static 'test1.pdf' %}";
            pdfjsLib.getDocument(url).promise.then(function (pdfDoc_) {
                pdfDoc = pdfDoc_;
                document.getElementById('page_count').textContent = pdfDoc.numPages;

                // Initial/first page rendering
                renderPage(pageNum);
            })
            .catch(function () {

                document.getElementById("textLayer").style.display = "none";

                document.getElementById("errorPdf").style.display = "block";

                document.getElementById("pdfcontainer").style.display = "none";

            }) ;

        }

        /**
         * Get page info from document, resize canvas accordingly, and render page.
         * @param num Page number.
         */
        function renderPage(num) {
            pageRendering = true;
            // Using promise to fetch the page
            pdfDoc.getPage(num).then(function (page) {
                var viewport = page.getViewport({ scale: scale });
                canvas.height = viewport.height;
                canvas.width = viewport.width;

                // Render PDF page into canvas context
                var renderContext = {
                    canvasContext: ctx,
                    viewport: viewport
                };
                var renderTask = page.render(renderContext);

                // Wait for rendering to finish
                renderTask.promise.then(function () {
                    pageRendering = false;
                    if (pageNumPending !== null) {
                        // New page rendering is pending
                        renderPage(pageNumPending);
                        pageNumPending = null;
                    }
                }).then(function () {
                    // Returns a promise, on resolving it will return text contents of the page
                    return page.getTextContent();
                }).then(function (textContent) {

                    var textLayer = document.querySelector(".textLayer");

                    textLayer.style.left = canvas.offsetLeft + 'px';
                    textLayer.style.top = canvas.offsetTop + 'px';
                    textLayer.style.height = canvas.offsetHeight + 'px';
                    textLayer.style.width = canvas.offsetWidth + 'px';

                    //	Pass the data to the method for rendering of text over the pdf canvas.
                    pdfjsLib.renderTextLayer({
                        textContent: textContent,
                        container: textLayer,
                        viewport: viewport,
                        textDivs: []
                    });

                }).then(function () {
                    changeSpanWidth()
                });
            });

            // Update page counters
            document.getElementById('page_num').textContent = num;
        }

        /**
         * If another page rendering in progress, waits until the rendering is
         * finised. Otherwise, executes rendering immediately.
         */
        function queueRenderPage(num) {
            if (pageRendering) {
                pageNumPending = num;
            } else {
                renderPage(num);
            }
        }

        /**
         * Displays previous page.
         */
        function onPrevPage() {
            if (pageNum <= 1) {
                return;
            }
            pageNum--;
            queueRenderPage(pageNum);
        }
        document.getElementById('prev').addEventListener('click', onPrevPage);

        /**
         * Displays next page.
         */
        function onNextPage() {
            if (pageNum >= pdfDoc.numPages) {
                return;
            }
            pageNum++;
            queueRenderPage(pageNum);
        }
        document.getElementById('next').addEventListener('click', onNextPage);

         /**
         * Zoom In.
         */
        function zoomIn() {
            scale = scale + 1.5;
            renderPage(pageNum)
        }
        // document.getElementById('zoomIn').addEventListener('click', zoomIn);

        /**
         * Zoom out.
         */
         function zoomOut() {
            scale = scale - 1.5;
            renderPage(pageNum)
        }
        // document.getElementById('zoomOut').addEventListener('click', zoomOut);


        document.onmouseup = document.onkeyup = document.onselectionchange = function () {

            let text = window.getSelection().toString().trim();

            text =  text.replace(/([.,\/#!$%\^&\*;:{}=\-_`~()\]\[])+$/g, "");

            if (text && lastFocus) {

                $("#" + lastFocus).val(text);

            }




        };

        
function onAccordionClick(button)
{
    console.log(global_count)
    var acc = document.getElementsByClassName("accordion");
    var i;
    console.log("accordion check")
   
    for (i = 0; i < acc.length; i++) {
        var panel = acc[i].nextElementSibling;
        panel.style.display = "none";
        if (i< count -1) {
            continue
        }
        var panel = acc[i].nextElementSibling;
        panel.style.display = "block";
        var elemEventHandler = function() { };
        acc[i].addEventListener("click", elemEventHandler , false);
        // $(acc[i]).removeAttr('onclick');
      acc[i].addEventListener("click", function() {
        /* Toggle between adding and removing the "active" class,
        to highlight the button that controls the panel */
        this.classList.toggle("active");
    
        /* Toggle between hiding and showing the active panel */
        var panel = this.nextElementSibling;
        if (panel.style.display === "block") {
          panel.style.display = "none";
        } else {
          panel.style.display = "block";
        }
      });
    }
}



        var count = 1;
        var global_count  = 1;
        var getFormId = "" ;

        // getdoc("http://localhost:8000/_1340149920.pdf")


        $("#addform").on("click", function () {
            console.log("add form")
            var cols = "";
            var l1 = $("<div class='form'>");
            var counter = 1;
            var localCount = 1;
            

            cols += '<input type="text" class="form-control" id="name' + count + '"/>';



            let html1 = $("<div>")
                //.append($("<div class='row justify-content-between m-0 p-0'>")
                //.append($("<div class='col-6'>")
                .append($('<button type="button" class="btn btn-warning remove-form" id="delete_' + count + '">-</button>'))
                    .append($("<button class='accordion' id='accordionBtn" + count + "'>New Form</button>"))
        
                    //.append($("<div class='col-6 d-flex flex-row justify-content-end'>")
                        ;
            //$("#content").empty();
            
            //currentFocus = "22222"
            //"input" + count + (localCount + 1) ;
            
            
            
            let html = html1.append( 
            $("<div  class='panel m-1 p-1'>").append($("<div class='row m-0 p-0'>")
            .append($("<div class='row m-0 p-0' > ")	
                .append($("<div class='col-md-6' > ")
                .append('<label >OK to Pay Stamp</label>')
                .append('<select class="form-select border  border-1 m-0 form-control"  placeholder="" id="pay_stamp' + count  + '"> <option>Yes</option><option>No</option> </select>'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Paykind code 1</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="paykind_code1' + count +  '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Paykind code 2</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="paykind_code2' + count +  '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Paykind code 3</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="paykind_code3' + count +  '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Sub#</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="sub' + count + '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label class="" >Val ID</label>')
                .append('<input autofocus type="text" class="  border border-1 m-0 form-control" placeholder="" id="valid' + count + '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Service State</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="servicestate' + count +'">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Claim Number</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="claimnumber' + count +'">'))
                
                .append($("<div class='col-md-6' > ")
                .append('<label >Requestor First name</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="firstname' + count +  '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Requestor Last name</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="lastname' + count +  '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Invoice No</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="invoiceno' + count +  '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Special instructions </label>')                
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="specialinstructions' + count  + '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Close claim</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="closeclaim' + count  + '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Total payable amount of the claim *</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="payableamount' + count + '">'))
                
                .append($("<div class='col-md-6' > ")
                .append('<label >Date of service*</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="dateofservice1' + count + '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >&nbsp;</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="dateofservice2' + count +  '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Tax ID </label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="taxid' + count + '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Payee Name*</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="payeename' + count + '">'))                
                .append($("<div class='col-md-6' > ")
                .append('<label >Address (Line 1)*</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="address1' + count +  '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Address (Line 2)*</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="address2' + count + '">'))
                
               
                .append($("<div class='col-md-6' > ")
                .append('<label >City Name*</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="cityname' + count + '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Zip Code*</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="zipcode' + count +  '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >State*</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="state' + count +  '">'))  
                .append($("<div class='col-md-6' > ")
                .append('<label >Nature of Payment</label>')
                .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="natureofpayment' + count +  '">'))
                .append($("<div class='col-md-6' > ")
                .append('<label >Taxable</label>')
                .append('<select class="form-select border border-1 m-0 form-control" placeholder="" id="taxable' + count  + '"> <option>Yes</option><option>No</option> </select>') )
                .append($("<div class='col-md-6' > ")
                .append('<label >Taxable to</label>')
                .append('<select class="form-select border border-1 m-0 form-control" placeholder="" id="taxableto' + count  + '"> <option>A- Attorney</option><option>B- Both (Attorney + Claimaint)</option><option>C- Claimaint</option><option>V- Vendor</option> </select>'))
                .append($("<div class='col-md-6' > ")
                .append('<label >MCSE</label>')
                .append('<select class="form-select border border-1 m-0 form-control" placeholder="" id="mcse' + count  + '"> <option>yes</option><option selected>No</option> </select>'))
                )));				
            ;
            l1.append(html);
            $("#formId").append(l1);

            if ( getFormId === "")
                {
                   $(this).blur();


                }

                else {

                    $("#" + getFormId).blur();

                   



                }

                $("#pay_stamp" + count ).focus();

               

                getFormId = "pay_stamp" + count ;

               

                lastFocus = "pay_stamp" + count ;

            
            
            count += 1;
            global_count += 1;
            onAccordionClick(count);

        //     var acc = document.getElementsByClassName("accordion");
        //     var i;
        //     console.log("accordion check")
   
        //     for (i = 0; i < acc.length; i++) {
        //         this.classList.toggle("active");
    
        // /* Toggle between hiding and showing the active panel */
        // var panel = this.nextElementSibling;
        // if (panel.style.display === "block") {
        //   panel.style.display = "none";
        // } else {
        //   panel.style.display = "block";
        // }
        //     }
        });

        

        $('#formId').click(function () {
            
            $(":focus").each(function () {
                console.log("delete form")
                //alert("Focused Elem_id = "+ this.id );
                lastFocus = this.id;

                
                var focus_id = this.id;
                var matches = focus_id.split("_");
                if (matches.length > 0) {
                    var deleteKey = matches[0]
                    if (deleteKey == "delete") {
                        
                        $(this).closest(".form").remove();
                        count -= 1;
                        //$("#l1 li").eq(matches[1]-1).remove();
                        //alert(matches[1]);

                    }

                }


            });




        });

        $("#submitId").click(function () {
            alert(lastFocus);
           
        });

        $("#b2").click(function () {
            if (count > 1) {
                $("#formId Div").last().remove();
                count -= 1;

            }


        });
        if ($('#btnradio2').is(':checked')) {
            url = converted_doc_url;

            //"{% static 'test1.pdf' %}";
            getdoc(url);
        }

       

        $($("#groupid")).change(function () {
            if ($('#btnradio2').is(':checked')) {
                url = converted_doc_url;
                //"{% static 'test1.pdf' %}";
                getdoc(url);
            }
            else if ($('#btnradio1').is(':checked')) {
                url = original_doc_url
                // alert(url);
                //"{% static 'test.pdf' %}";
                getdoc(url);

            }

        });

        var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    /* Toggle between adding and removing the "active" class,
    to highlight the button that controls the panel */
    this.classList.toggle("active");

    /* Toggle between hiding and showing the active panel */
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}

    });

}
export default pdfFunction;