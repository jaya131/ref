import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';

export const getUser =() => {
const userStr = sessionStorage.getItem("user");
if (userStr) return JSON.parse(userStr).f_name;
else return null;

}

export const getToken=() => {
return sessionStorage.getItem ("token") || null;
}

export const setUserSession = (token, user) =>{
 sessionStorage.setItem("token", token);
sessionStorage.setItem ("user", JSON.stringify(user));
}
export const removedUserSession = () => {
sessionStorage.removeItem("token");
sessionStorage.removeItem("user");

}
export const getUserSession = () =>{
    // console.log(JSON.parse(sessionStorage.getItem("token")));
    // console.log(sessionStorage.getItem("token"));
return  JSON.parse(sessionStorage.getItem("token")).access;

}
export const showToaster = ((message, notificationType) => {
    if (notificationType == 'error'){
        toast.error(message, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            });
    }
    else if(notificationType == 'success'){
        toast.success(message, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            });
    } else if(notificationType == "info") {
        toast.warn(message, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            });
    }

});

