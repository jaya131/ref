// If absolute URL from the remote server is provided, configure the CORS
// header on that server.
var jQueryScript = document.createElement('script');  
jQueryScript.setAttribute('src','https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js');
document.head.appendChild(jQueryScript);

$(document).ready(function () {
    var original_doc_url = "http://localhost:8000/_1340149920.pdf";
    var converted_doc_url = "http://localhost:8000/_1340149920.pdf";
    
    $("#pdfcontainer").hide();
var url = "http://localhost:8000/_1340149920.pdf";;
// "{% static 'test1.pdf' %}";

// Loaded via <script> tag, create shortcut to access PDF.js exports.
var pdfjsLib = null;
//window['pdfjs-dist/build/pdf'];

// The workerSrc property shall be specified.
// pdfjsLib.GlobalWorkerOptions.workerSrc = '//mozilla.github.io/pdf.js/build/pdf.worker.js';

var pdfDoc = null,
    pageRendering = false,
    pageNumPending = null,
    //scale = 0.8,
    scale = 0;

var lastFocus="";
pdfjsLib = window['pdfjs-dist/build/pdf'];
pdfjsLib.GlobalWorkerOptions.workerSrc = '//mozilla.github.io/pdf.js/build/pdf.worker.js';
function getdoc(url){
    if (url && url != "None"){
        //bject.prototype.toString.call(url)
        $("#pdfcontainer").show();
        alert(url);
        
    }else{
        $("#pdfcontainer").hide();
        return;
    }
    
    pageNum=1;   
    pageRendering = false;
    pageNumPending = null;
    scale = 1.1;
    canvas = document.getElementById('the-canvas');
    ctx = canvas.getContext('2d');
    
    //url = "{% static 'test1.pdf' %}";
    pdfjsLib.getDocument(url).promise.then(function (pdfDoc_) {
        pdfDoc = pdfDoc_;
        document.getElementById('page_count').textContent = pdfDoc.numPages;

        // Initial/first page rendering
        renderPage(pageNum);
    });
}

/**
 * Get page info from document, resize canvas accordingly, and render page.
 * @param num Page number.
 */
function renderPage(num) {
    pageRendering = true;
    // Using promise to fetch the page
    pdfDoc.getPage(num).then(function (page) {
        var viewport = page.getViewport({ scale: scale });
        canvas.height = viewport.height;
        canvas.width = viewport.width;

        // Render PDF page into canvas context
        var renderContext = {
            canvasContext: ctx,
            viewport: viewport
        };
        var renderTask = page.render(renderContext);

        // Wait for rendering to finish
        renderTask.promise.then(function () {
            pageRendering = false;
            if (pageNumPending !== null) {
                // New page rendering is pending
                renderPage(pageNumPending);
                pageNumPending = null;
            }
        }).then(function () {
            // Returns a promise, on resolving it will return text contents of the page
            return page.getTextContent();
        }).then(function (textContent) {

            // Assign CSS to the textLayer element
            var textLayer = document.querySelector(".textLayer");

            textLayer.style.left = canvas.offsetLeft + 'px';
            textLayer.style.top = canvas.offsetTop + 'px';
            textLayer.style.height = canvas.offsetHeight + 'px';
            textLayer.style.width = canvas.offsetWidth + 'px';

            // Pass the data to the method for rendering of text over the pdf canvas.
            pdfjsLib.renderTextLayer({
                textContent: textContent,
                container: textLayer,
                viewport: viewport,
                textDivs: []
            });
        });
    });

    // Update page counters
    document.getElementById('page_num').textContent = num;
}

/**
 * If another page rendering in progress, waits until the rendering is
 * finised. Otherwise, executes rendering immediately.
 */
function queueRenderPage(num) {
    if (pageRendering) {
        pageNumPending = num;
    } else {
        renderPage(num);
    }
}

/**
 * Displays previous page.
 */
function onPrevPage() {
    if (pageNum <= 1) {
        return;
    }
    pageNum--;
    queueRenderPage(pageNum);
}
document.getElementById('prev').addEventListener('click', onPrevPage);

/**
 * Displays next page.
 */
function onNextPage() {
    if (pageNum >= pdfDoc.numPages) {
        return;
    }
    pageNum++;
    queueRenderPage(pageNum);
}
document.getElementById('next').addEventListener('click', onNextPage);

document.onmouseup = document.onkeyup = document.onselectionchange = function () {
    text = window.getSelection().toString();
    if (text && lastFocus ) {
        $("#"+lastFocus).val(text);
        }
    

};




    var count=1;
   

    $("#b1").on("click", function () {
        var cols = "";
    var l1=$("<li class='border border-2 '>");
    var counter=1;
    var localCount=1;

    cols += '<input type="text" class="form-control" id="name' + count + '"/>';



    html1 = $("<div class='container-fluid m-0 p-0'>")
        .append($("<div class='row justify-content-between m-0 p-0'>").append($("<div class='col-2'>")
        .append($("<h6 class='mt-2 ms-1'>").append("Information")))
        .append($("<div class='col-1 d-flex flex-row justify-content-end'>")
        .append($('<button type="button" class="btn btn-primary" id="delete_'+count+'">Remove</button>'))));
    //$("#content").empty();
    html=$("<div class='container-fluid m-1 p-0'>").append($("<div class='row m-0 p-0'>")
        .append($("<div class='col-6 m-0 p-0'> ")
        .append('<input type="text" class="border border-1 m-0 form-control" placeholder="input1" id="input'+ count+localCount +'">')
        .append('<input type="text" class="border border-1 m-0 form-control" placeholder="input2" id="input'+ count+ (localCount+1)+'">'))
       
        .append($("<div class='col-6'>")
        .append('<input type="text" class="border border-1 form-control" placeholder="input1" id="input'+ count+(localCount+2)+'">')
        .append('<input type="text"class="border border-1 form-control" placeholder="input2" id="input'+ count+(localCount+3)+'">')));
    ;
    l1.append(html1.append(html));
   


    $("#formId").append(l1);
    count +=1;
    });



    $('#formId').click(function(){
        $(":focus").each(function() {
        //alert("Focused Elem_id = "+ this.id );
        lastFocus=this.id ;


        var focus_id = this.id;
        var matches = focus_id.split("_");
        if (matches.length >0){
            var deleteKey=matches[0]
            if (deleteKey == "delete"){
                $(this).closest("li").remove();
                //$("#l1 li").eq(matches[1]-1).remove();
                //alert(matches[1]);

            }

        }
        

        });




     });

$("#save").click(function () {
    alert(lastFocus);
});

$("#b2").click(function(){
    if (count > 1){
        $("#formId li").last().remove();
        count -=1;

    }
    

});
if ($('#btnradio2').is(':checked')){
url = converted_doc_url;

//"{% static 'test1.pdf' %}";
getdoc(url);
}

$($("#groupid")).change(function(){
if ($('#btnradio2').is(':checked')){
    url = converted_doc_url;
    //"{% static 'test1.pdf' %}";
    getdoc(url);
}
else if($('#btnradio1').is(':checked')){
    url = original_doc_url
   // alert(url);
    //"{% static 'test.pdf' %}";
    getdoc(url);

}
           
        });
});





