import React, { useState, useEffect, useRef } from 'react';
import { getUser, removedUserSession, getUserSession, showToaster } from "../Utils/common";
import { BrowserRouter as Router, Link } from 'react-router-dom';
import { Modal, Button } from 'react-bootstrap';
import { Helmet } from "react-helmet";
// import $ from "jquery";
import pdfFunction from './pdffuction';
import formFunction from './formFunction';
import deleteForm from './deleteForm';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';
// import { formvalidation } from './formvalidation';


export default function OperatorValidate(props) {

	<Helmet>
		<script src="./js/custom-pdf.js" type="text/javascript" />
	</Helmet>

	const [documentLink, setDocumentLink] = useState(false);
	const setDocumentLinkFunction = (link) => setDocumentLink(link);
	const [show, setShow] = useState(false);
	const handleClose = () => setShow(false);
	const handleShow = () => setShow(true);
	const childRef = useRef(null);
	const [open, setOpen] = useState(false);
	const user = getUser();
	const [loading, setLoading] = useState(false);
	const [paykind_code1, setPaykind_code1] = useState('');
	const [paykind_code2, setPaykind_code2] = useState('');
	const [paykind_code3, setPaykind_code3] = useState('');
	const [valid, setValid] = useState('');
	const [sub, setSub] = useState('');
	const [servicestate, setServicestate] = useState('');
	const [claimnumber, setClaimnumber] = useState('');
	const [invoiceno, setInvoiceno] = useState('');
	const [firstname, setFirstname] = useState('');
	const [lastname, setLastname] = useState('');
	const [specialinstructions, setSpecialinstructions] = useState('');
	const [dateofservice1, setDateofservice1] = useState('');
	const [dateofservice2, setDateofservice2] = useState('');
	const [taxid, setTaxid] = useState('');
	const [payeename, setPayeename] = useState('');
	const [mcse, setMcse] = useState('');
	const [address1, setAddress1] = useState('');
	const [address2, setAddress2] = useState('');
	const [cityname, setCityname] = useState('');
	const [zipcode, setZipcode] = useState('');
	const [state, setState] = useState('');
	const [natureofpayment, setNatureofpayment] = useState('');
	const [taxable, setTaxable] = useState('');
	const [payableamount, setPayableamount] = useState('');
	const [taxableto, setTaxableto] = useState('');
	const [closeclaim, setCloseclaim] = useState('');
	const [pay_stamp, setPay_stamp] = useState('');
	const [successMessage, setSuccessMessage] = React.useState("");
	const [currentFile, setCurrentFile] = React.useState(props.location.state.file);

	const handleLogout = () => {
		removedUserSession();
		props.history.push('/');
	}



	async function GetFile(is_file) {

		console.log("inside operator validate, get file")
		console.log(props.location.state.file)
		let body = {};
		if (is_file) {
			body = {
				"case_id": props.location.state.file
			}
		}
		const response = await fetch(process.env.REACT_APP_API_URL + "/api/get_file/", {
			method: "POST",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Headers": "*",
				"Access-Control-Allow-Methods": "*",
				"Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false,
				"Authorization": "Bearer " + getUserSession()
			},
			body: JSON.stringify(body)
		}).then(response => response.json())
			.then(data => {
				// setDocumentLinkFunction(data.data.converted_doc_url);
				if (data.error) {
					if (data.message == "File not available") {
						props.history.push('/operator/Operatorvalidate');
					}
					props.history.push('/operator/Operatorlanding')
				}

				console.log("response")
				let converted_doc = data.data.converted_doc_url;
				let original_doc = data.data.original_doc_url;
				// comment later
				converted_doc = converted_doc.replace("http://10.146.225.68", "http://localhost");
				original_doc = original_doc.replace("http://10.146.225.68", "http://localhost")
				if (true) {
					setCurrentFile(converted_doc.split("/").slice(-1)[0].split(".")[0])
				}

				pdfFunction(converted_doc, original_doc);
				formFunction(data.data.default_json.extracted_json);

			}).catch(error => {
				console.log("catch")
				console.log(error);
			});
	}

	useEffect(() => {

		GetFile(true);
	}, []);



	const handleValidateform = async (submitType) => {
		
		handleClose();
		let extracted_json = {};
		let count = 0;
		let api_key = "";
		if (submitType == "submit") {
			api_key = process.env.REACT_APP_API_URL + "/api/save_file/";
		} else if (submitType == "draft") {
			api_key = process.env.REACT_APP_API_URL + "/api/save_as_draft/";
		} else {
			api_key = process.env.REACT_APP_API_URL + "/api/save_as_review/";
		}
		let is_numeric =/^\d+$/;
		let is_amount=/^[+-]?[0-9]{1,3}(?:,?[0-9]{3})*\.[0-9]{2}$/;
		let is_alpha =/^[a-zA-Z ]*$/;
		var date_regex = /^\d{2}\/\d{2}\/\d{4}$/ ;
		let is_zipcode= /^(\d{5}(?:\-\d{4})?)$/;
		while (true) {
			// let form = {};

			if (document.getElementById("paykind_code1" + count) != null) {
				// if (submitType != "draft" )
				 if (submitType == "submit" ) {
					if (document.getElementById("paykind_code1" + count).value && !is_numeric.test( document.getElementById("paykind_code1" + count).value)) {
						showToaster('Enter Paykind Code in Numeric only', 'info')
						document.getElementById("paykind_code1" + count).focus()
						return
					} 
					if (document.getElementById("paykind_code2" + count).value && !is_numeric.test( document.getElementById("paykind_code2" + count).value)) {
						showToaster('Enter Paykind Code in Numeric only', 'info')
						document.getElementById("paykind_code2" + count).focus()
						return
					} 
					if (document.getElementById("paykind_code3" + count).value && !is_numeric.test( document.getElementById("paykind_code3" + count).value)) {
						showToaster('Enter Paykind Code in Numeric only', 'info')
						document.getElementById("paykind_code3" + count).focus()
						return
					} 
					if (document.getElementById("sub" + count).value && !is_numeric.test( document.getElementById("sub" + count).value)) {
						showToaster('Enter Sub in Numeric only', 'info')
						document.getElementById("sub" + count).focus()
						return
					}
					// if (document.getElementById("valid" + count).value && !is_numeric.test( document.getElementById("valid" + count).value)) {
					// 	showToaster('Enter Val ID in Numeric only', 'info')
					// 	document.getElementById("valid" + count).focus()
					// 	return
					// }
					if (document.getElementById("servicestate" + count).value && !is_alpha.test( document.getElementById("servicestate" + count).value)) {
						showToaster('Please enter correct Service State', 'info')
						document.getElementById("servicestate" + count).focus()
						return
					} 
					if (document.getElementById("claimnumber" + count).value && !is_numeric.test( document.getElementById("claimnumber" + count).value)) {
						showToaster('Enter Claim Number in Numeric only', 'info')
						document.getElementById("claimnumber" + count).focus()
						return
					}
					if (document.getElementById("firstname" + count).value && !is_alpha.test( document.getElementById("firstname" + count).value)) {
						showToaster('Please enter correct First Name', 'info')
						document.getElementById("firstname" + count).focus()
						return
					} 
					if (document.getElementById("lastname" + count).value && !is_alpha.test( document.getElementById("lastname" + count).value)) {
						showToaster('Please enter correct Last Name', 'info')
						document.getElementById("lastname" + count).focus()
						return
					} 
					if (document.getElementById("invoiceno" + count).value && !is_numeric.test( document.getElementById("invoiceno" + count).value)) {
						showToaster('Enter Invoice No in Numeric only', 'info')
						document.getElementById("invoiceno" + count).focus()
						return
					}

					if (document.getElementById("payableamount" + count).value == '') {
						showToaster('Payable amount cannot be empty', 'info')
						document.getElementById("payableamount" + count).focus()
						return
					} 					
					if (!is_amount.test( document.getElementById("payableamount" + count).value)) {
						showToaster('Enter Total payable amount in correct format (.00)', 'info')
						document.getElementById("payableamount" + count).focus()
						return
					} 
					if (document.getElementById("dateofservice1" + count).value == '') {
						showToaster('Date of service cannot be empty', 'info')
						document.getElementById("dateofservice1" + count).focus()
						return
					}
					if (!date_regex.test( document.getElementById("dateofservice1" + count).value)) {
						showToaster('Enter Date in mm/dd/yyyy format', 'info')
						document.getElementById("dateofservice1" + count).focus()
						return
					} 
					if (document.getElementById("dateofservice2" + count).value == '') {
						showToaster('Date of service cannot be empty', 'info')
						document.getElementById("dateofservice2" + count).focus()
						return
					}
					if (!date_regex.test( document.getElementById("dateofservice2" + count).value)) {
						showToaster('Enter Date in mm/dd/yyyy format', 'info')
						document.getElementById("dateofservice2" + count).focus()
						return
					} 
					
					
					
					
					if (document.getElementById("taxid" + count).value && !is_numeric.test( document.getElementById("taxid" + count).value)) {
						showToaster('Enter Tax ID in Numeric only', 'info')
						document.getElementById("taxid" + count).focus()
						return
					}
					if (document.getElementById("payeename" + count).value == '') {
						showToaster('Payee Name cannot be empty', 'info')
						document.getElementById("payeename" + count).focus()
						return
					}
					if (!is_alpha.test( document.getElementById("payeename" + count).value)) {
						showToaster('Please enter correct Payee Name', 'info')
						document.getElementById("payeename" + count).focus()
						return
					} 
					
					
					if (document.getElementById("address1" + count).value == '') {
						showToaster('Address  cannot be empty', 'info')
						document.getElementById("address1" + count).focus()
						return
					}
					if (document.getElementById("cityname" + count).value == '') {
						showToaster('City Name  cannot be empty', 'info')
						document.getElementById("cityname" + count).focus()
						return
					}
					if (!is_alpha.test( document.getElementById("cityname" + count).value)) {
						showToaster('Please enter correct City Name', 'info')
						document.getElementById("cityname" + count).focus()
						return
					} 
					if (document.getElementById("zipcode" + count).value == '') {
						showToaster('Zipcode  cannot be empty', 'info')
						document.getElementById("zipcode" + count).focus()
						return
					}
					if (!is_zipcode.test( document.getElementById("zipcode" + count).value)) {
						showToaster('Please enter correct Zip code', 'info')
						document.getElementById("zipcode" + count).focus()
						return
					} 
					if (document.getElementById("state" + count).value == '') {
						showToaster('State  cannot be empty', 'info')
						document.getElementById("state" + count).focus()
						return
					}
					if (!is_alpha.test( document.getElementById("state" + count).value)) {
						showToaster('Please enter correct State', 'info')
						document.getElementById("state" + count).focus()
						return
					} 
					// if (document.getElementById("natureofpayment" + count).value && !is_alpha.test( document.getElementById("natureofpayment" + count).value)) {
					// 	showToaster('Please enter correct Nature of payment', 'info')
					// 	document.getElementById("natureofpayment" + count).focus()
					// 	return
					// } 

				}


				let form_data = {
					pay_stamp: document.getElementById("pay_stamp" + count).value,
					paykind_code1: document.getElementById("paykind_code1" + count).value,
					paykind_code2: document.getElementById("paykind_code2" + count).value,
					paykind_code3: document.getElementById("paykind_code3" + count).value,
					valid: document.getElementById("valid" + count).value,
					sub: document.getElementById("sub" + count).value,
					servicestate: document.getElementById("servicestate" + count).value,
					claimnumber: document.getElementById("claimnumber" + count).value,
					invoiceno: document.getElementById("invoiceno" + count).value,
					firstname: document.getElementById("firstname" + count).value,
					lastname: document.getElementById("lastname" + count).value,
					specialinstructions: document.getElementById("specialinstructions" + count).value,
					closeclaim: document.getElementById("closeclaim" + count).value,
					payableamount: document.getElementById("payableamount" + count).value,
					dateofservice1: document.getElementById("dateofservice1" + count).value,
					dateofservice2: document.getElementById("dateofservice2" + count).value,
					taxid: document.getElementById("taxid" + count).value,
					payeename: document.getElementById("payeename" + count).value,
					address1: document.getElementById("address1" + count).value,
					address2: document.getElementById("address2" + count).value,
					cityname: document.getElementById("cityname" + count).value,
					zipcode: document.getElementById("zipcode" + count).value,
					state: document.getElementById("state" + count).value,
					natureofpayment: document.getElementById("natureofpayment" + count).value,
					taxable: document.getElementById("taxable" + count).value,
					taxableto: document.getElementById("taxableto" + count).value,
					mcse: document.getElementById("mcse" + count).value,


				}
				extracted_json['form' + count] = form_data
				count++;
			} else {
				break
			}

		}

		console.log(extracted_json)
		//return
		let comment = "";
		if (document.getElementById("review") != null) {
			comment = document.getElementById("review").value;
		}
		const response = await fetch(api_key, {
			method: "POST",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Headers": "*",
				"Access-Control-Allow-Methods": "*",
				"Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false,
				"Authorization": "Bearer " + getUserSession()
			},
			body: JSON.stringify({
				"data": {
					"case_id": props.location.state.file,
					"extracted_json": {
						"case_id": props.location.state.file,
						"extracted_json": extracted_json,
						"comment": comment,
						"multiform": document.getElementById("multiple_claim").checked
					},
					"rush_case": document.getElementById("rush_case").checked,
					"comment": comment,

					// ,priority: 0

				}
			})
		}).then(response => response.json())
			.then(data => {
				console.log("response")
				console.log(data)
				setLoading(false);
				if (data.error === true) {
					showToaster(data.message, 'error')
				}
				else {
					// setSuccessMessage(data.message)
					showToaster(data.message + " for case -" + currentFile, 'success');
					if (submitType != "draft") {
						deleteForm(extracted_json);
						GetFile(false);

					}

				}


			}).catch(error => {
				console.log("catch")
				console.log(error)
				setLoading(false);
				showToaster('Something went wrong', 'error')
			});

	}

	return (

		<div className="operator">
			<Modal show={show} onHide={handleClose}>
				<Modal.Header closeButton>
					Send for review
				</Modal.Header>
				<Modal.Body><textarea id="review" class="form-control" placeholder='Enter your review
' name="review" rows="4" cols="50">
				</textarea></Modal.Body>
				<Modal.Footer>

					<Button variant="warning" onClick={() => handleValidateform("review")}>
						Submit Review
					</Button>
				</Modal.Footer>
			</Modal>
			<div className="row py-4">
				<div className='col-md-7'><Link className=" back" to={'/operator/Operatorlanding'}></Link> <div className="optcase-id"> Case ID - {currentFile}</div> </div>

				<div className="col-md-5"><a href="" type="link" className="logout" onClick={handleLogout}>Logout</a></div>

			</div>

			<div className="row">
				<div className=" col-md-7">

				</div>
				<div className="col-md-5 row">
					<div className="col-md-7 row">

						<div className="col-md-6 py-2">

							<label className='col-8'>Rush case</label>
							<input type="checkbox" className='col-2' id="rush_case" name="Rush cases" ></input>

						</div>
						<div className="col-md-6 py-2">
							<label className='col-8'>Multiple Claim</label>
							<input type="checkbox" className='col-2' id="multiple_claim" name="Multiple Claim" ></input>

						</div>

					</div>
					<div className="col-md-5">
						<button type="button" class="btn btn-outline-warning add-form ms-2 d-flex flex-row justify-content-end" id="addform">+ Add form</button></div>

				</div>
			</div>
			<div className="row  scroll-box">
				<div className="col-md-7 padding-right0" >

					<div className='pdf-container'>

						<div class="col" >



						</div>
						<div class="row pdf-head justify-content-between">
							<div class=" col-2 d-flex flex-row justify-content-start">
								<button type="button" class="btn btn-warning pdf-button" id="prev">Previous</button>
							</div>
							<div class=" col-2">
								<span>Page: <span id="page_num"></span> / <span id="page_count"></span></span>
							</div>
							<div class=" col-2 d-flex flex-row justify-content-end">
								<button type="button" class="btn btn-warning pdf-button" id="next">Next</button>
							</div>


						</div>
						<p id="errorPdf" style={{ display: "none", color: "red" }}>Error in loading PDF. Send this file for review.</p>

						<div className='overflow' id="pdfcontainer">
							<canvas id="the-canvas"></canvas>
							<div class="textLayer" id='textLayer'></div>
						</div>




						{/* <MyComponent state={documentLink} /> */}
						{/* <embed src="http://localhost:8000/expense/_1340049686.pdf" width="800px" height="2100px" /> */}
					</div>
				</div>
				<div className="col-md-5 padding-left0" >
					<div id='formId'>
						<button class="active accordion" id="accordionBtn1">Details to be Filled</button>
						<div class="panel" id="panel" style={{ display: "block" }} >

							<div className="row"  >
								{successMessage && <div className="success"> {successMessage} </div>}

								<div className="col-md-6">
									<div className="form-group">
										<label >OK to Pay Stamp</label>
										<select class="form-select" id="pay_stamp0">
											<option value="Yes" selected>Yes</option>
											<option value="No" >No</option>

										</select>
										{/* <input type="text" className="form-control"  /> */}
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="Paykind_code">Paykind code 1</label>
										<input type="text" className="form-control" id="paykind_code10" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="Paykind_code">Paykind code 2</label>
										<input type="text" className="form-control" id="paykind_code20" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="Paykind_code">Paykind code 3</label>
										<input type="text" className="form-control" id="paykind_code30" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="Sub">Sub#</label>
										<input type="text" className="form-control" id="sub0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="Val_ID">Val ID</label>
										<input type="text" className="form-control" id="valid0" />
									</div>
								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Service State</label>
										<input type="text" className="form-control" id="servicestate0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="ClaimNumber">Claim Number</label>
										<input type="text" className="form-control" id="claimnumber0" />
									</div>
								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Requestor First name</label>
										<input type="text" className="form-control" id="firstname0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Requestor Last name</label>
										<input type="text" className="form-control" id="lastname0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label>Invoice No</label>
										<input type="text" className="form-control" id="invoiceno0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="Specialinstructions">Special instructions</label>
										<input type="text" className="form-control" id="specialinstructions0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Close Claim</label>
										<select class="form-select" value={closeclaim} onChange={e => setCloseclaim(e.target.value)} id="closeclaim0">
											<option value="Yes" >Yes</option>
											<option value="No" selected>No</option>

										</select>

									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Total payable amount of the claim <span className='star'>*</span></label>
										<input type="text" required className="form-control" id="payableamount0" />
									</div>
								</div>


								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Date of service<span className='star'>*</span></label>
										<input type="text" className="form-control" placeholder='From' id="dateofservice10" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">&nbsp;</label>
										<input type="text" className="form-control" placeholder='To' id="dateofservice20" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Tax ID </label>
										<input type="text" required className="form-control" id="taxid0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Payee Name<span className='star'>*</span></label>
										<input type="text" className="form-control" id="payeename0" />
									</div>
								</div>
								{/* <div className="col-md-6">
									<div className="form-group">
										<label htmlFor=""></label>
										<input type="text" className="form-control" id="remitto0" />
									</div>
								</div> */}
								<div className="col-md-6">
									<div className="form-group">
										<label >Address/Remit To (Line 1)<span className='star'>*</span></label>
										<input type="text" className="form-control" id="address10" />
									</div>
								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Address/Remit To (Line 2)<span className='star'>*</span></label>
										<input type="text" className="form-control" id="address20" />
									</div>
								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">City Name<span className='star'>*</span></label>
										<input type="text" className="form-control" id="cityname0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Zip Code<span className='star'>*</span></label>
										<input type="text" className="form-control" id="zipcode0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">State<span className='star'>*</span></label>
										<input type="text" className="form-control" id="state0" />
									</div>
								</div>
								<div className='clear'></div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Nature of Payment</label>
										<input type="text" className="form-control" id="natureofpayment0" />
									</div>
								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Taxable</label>
										<select class="form-select" value={taxable} onChange={e => setTaxable(e.target.value)} id="taxable0">
											<option value="Yes" >Yes</option>
											<option value="No" selected>No</option>

										</select>
									</div>
								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Taxable to</label>
										<select class="form-select" value={taxableto} onChange={e => setTaxableto(e.target.value)} id="taxableto0">
											<option value="" hidden selected>Select</option>
											<option value="A">A- Attorney</option>
											<option value="B">B- Both (Attorney + Claimaint)</option>
											<option value="C">C- Claimaint</option>
											<option value="V">V- Vendor</option>

										</select>
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">MCSE/MBR</label>
										<select class="form-select" id="mcse0">
											<option value="Yes" >Yes</option>
											<option value="No" selected>No</option>

										</select>
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
			<div style={{ visibility: 'hidden' }}>
				<div class="button-center d-flex justify-content-center btn-group" role="group" aria-label="Basic radio toggle button group" id="groupid">
					<input type="radio" class="btn-check" name="btnradio" id="btnradio1" autocomplete="off" />
					<label class="btn btn-outline-warning" style={{ width: '150px' }} for="btnradio1">Orginal</label>

					<input type="radio" class="btn-check" name="btnradio" id="btnradio2" autocomplete="off" checked />
					<label class="btn btn-outline-warning" style={{ width: '150px' }} for="btnradio2">Processed</label>
				</div>

			</div>
			<div className="row py-3">
				<div className="col-md-11">


					<Button className="linksec" variant="outline-warning" onClick={() => handleValidateform("draft")} >Save as Draft</Button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <Button className="linksec" variant="outline-warning" onClick={handleShow}>
						Send for Review</Button></div>
				<div className="col-md-1">
					{/* <p>{Post.value}</p> */}
					<input className="form-group  btn btn-warning  sub-button" type="button" value={"Submit"} onClick={() => handleValidateform("submit")} /></div>


			</div>

			<ToastContainer
				position="top-right"
				autoClose={5000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
				theme='colored' />

		</div>



	)
}

