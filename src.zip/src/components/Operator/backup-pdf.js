import React, { Component } from 'react';
import PDFViewer from 'pdf-viewer-reactjs'


  
const ExamplePDFViewer = () => {
  return (
    <PDFViewer
      document={{url: 'https://arxiv.org/pdf/quant-ph/0410100.pdf',}}
      navbarOnTop={true}      
      scale={1.235}
      canvasCss={true}
      Type={true}
     
    
    />     
  )
}

export default ExamplePDFViewer;