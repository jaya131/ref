import React, { useState, useEffect } from 'react';
import { showToaster, getUserSession} from "../Utils/common";
import {Col, Form} from 'react-bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';
import { addUserValidations } from './adminValidations';


const Adduser = (props) => {
	const [email, setEmail] = useState('');
	const [first_name, setFirst_name] = useState('');
	const [username, setUsername] = useState('');
	const [last_name, setLast_name] = useState('');
	const [userid, setUserid] = useState('');
	const [password, setPassword] = useState('');
	const [role, setRole] = useState('');
	const [contact_number, setContact_number] = useState('');
	const [Post, setPost] = useState([]);
	const [error, setError] = useState(null);	
	const [loading, setLoading] = useState(false);
	const [lob, setLob] = useState([]);
	const [is_admin, setIsAdmin] = useState(0);
	const [is_manager, setIsmanager] = useState(0);
	const [successMessage, setSuccessMessage] = React.useState("");
	
	const handleAdduser = async () => {

		let validated = addUserValidations(email, first_name, last_name, username, role, password, lob, contact_number, "addUser")
		if (validated.error) {
			showToaster(validated.message, "info");
			return
		}
		if ('role' == '1') {
			setIsAdmin(1);
			setIsmanager(0);
		} else if ('role' == '2') {
			setIsAdmin(0);
			setIsmanager(1);
		} else {
			setIsAdmin(0);
			setIsmanager(0);
		}
		console.log(getUserSession());

		
		const response = await fetch(process.env.REACT_APP_API_URL+"/api/users/", {
			method: "POST",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Headers": "*",
				"Access-Control-Allow-Methods": "*",
				"Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false,
				"Authorization": "Bearer " + getUserSession()
			},
			
			body: JSON.stringify({
				"data": {
					user: {
						email: email,
						first_name: first_name,
						username: username,
						last_name: last_name,
						is_manager: is_manager,
						is_admin: is_admin,
						password: password,
						contact_number:contact_number
					},
					"proccess_type": lob

				}
			})
		}).then(response => response.json())
			.then(data => {
				console.log("response")
				console.log(data)
				setLoading(false);				
				if (data.error == true) {
					showToaster(data.message, 'error')
				}
				else {
				// setSuccessMessage(data.message)
				showToaster(data.message, 'success');
			}


			}).catch(error => {
				console.log("catch")
				console.log(error)
				setLoading(false);
				showToaster('Something went wrong', 'error')
			});
	}
	return (
		<div className="col-md-12  user-details">

			<h2>Add User</h2>
			<div className="row">
				{successMessage && <div className="success"> {successMessage} </div>}
				<div className="form-group col-md-6">
					<label className="form-label"  >First Name</label>
					<input type="text" required
        value={first_name}  onChange={e => setFirst_name(e.target.value)} className="form-control" id="" />
				</div>
				<div className="form-group col-md-6">
				<label className="form-label"  >Last Name</label>
					<input type="text" required
        value={last_name}  onChange={e => setLast_name(e.target.value)} className="form-control" id="" />
				</div>
				<div className="form-group col-md-6">
					<label className="form-label">User ID</label>
					<input type="text" required value={username} onChange={e => setUsername(e.target.value)} className="form-control" id="" />
				</div>
				<div className="form-group col-md-6" as={Col} controlId="my_multiselect_field">
					<label className="form-label" >Line of Business</label>
					<select className="form-control" as="select" multiple value={lob} onChange={e => setLob([].slice.call(e.target.selectedOptions).map(item => item.value))}>
						<option value="Expense">Expense</option>
						<option value="Indemnity">Indemnity</option>
						<option value="RCS">RCS</option>
					</select>	
				</div>
				<div className=" form-group col-md-6">
					<label className="form-label" >Role</label>
					<Form.Select aria-label="" required value={role} onChange={e => setRole(e.target.value)} className="form-control">
						<option>select</option>
						<option value="1">Admin</option>
						<option value="2">Manager</option>
						<option value="3">Operator</option>
					</Form.Select>
				</div>
				<div className="form-group col-md-6">
					<label className="form-label" >Contact number</label>
					<input type="text" value={contact_number} onChange={(e) => {
						setContact_number(e.target.value);
						if (e.target.value.length > 10) {
							setError(true);
						}
					}} className="form-control" id="" />
				</div>
				<div className="form-group col-md-6">
					<label className="form-label" >Email address</label>
					<input type="email" value={email}  required onChange={e => setEmail(e.target.value)}  className="form-control" id="" />
				</div>
				<div className="form-group col-md-6">
					<label className="form-label" >Password </label>
					<input type="password" value={password} required onChange={e => setPassword(e.target.value)} className="form-control" id="" />
				</div>
				<div className=" form-group col-md-12">
					<p>{Post.value}</p>
					<input className="form-group  btn btn-warning  sub-button" type="button" value={loading ? "Loading..." : "Add User"}  onClick={handleAdduser} />
				</div>
			</div>
			<ToastContainer
		position="top-right"
		autoClose={5000}
		hideProgressBar={false}
		newestOnTop={false}
		closeOnClick
		rtl={false}
		pauseOnFocusLoss
		draggable
		pauseOnHover
		theme='colored'
/>
		</div>



	)
}
export default Adduser;