import React, {Component} from 'react';
import logo from '../../images/logo.png';
import logoexl from '../../images/exl-logo.png';
import { Button } from 'react-bootstrap';
import Adduser from './Adduser';
import Updateuser from './Updateuser';
import Deactivate from './Deactivate';
import Activate from './Activate';
import { BrowserRouter as Router, Route, Redirect, Link } from 'react-router-dom';
import {getToken, getUser, removedUserSession} from "../Utils/common";
import 'react-toastify/dist/ReactToastify.min.css';



export default function Admin  (props)  {
	
	const user = getUser();
	const handleLogout =() => {
		removedUserSession();
		props.history.push('/');		
	}


    return(
		
		<div className="background">
			<nav className="bg-nav">
				<div className="row col-12 d-flex justify-content-center text-white">
					<div className="col-md-3 col-xs-9"><img className="logo-inner" src={logo}/></div>
					<div className="col-md-8">&nbsp;</div>
					<div className="col-md-1 col-xs-3"><img className="logo-exl" src={logoexl}/></div>					
				</div>
			</nav>
			<div className="section-code">
			<div className="row">
				<div className="col-md-12">
					<h1>Welcome { user }! <a href="" type="link"  className="logout" onClick={handleLogout}>Logout</a> </h1>
				</div> 
			</div>
			<div className="row">
				<div className="row ">	
					<div className="col-md-3">
						<nav>
								<Link to={'/admin/Adduser'}><Button className="col-md-12 btn-admin" variant="outline-warning">Add User</Button></Link>
								<Link to={'/admin/Updateuser'}><Button className="col-md-12 btn-admin" variant="outline-warning">Update User</Button></Link>
								<Link to={'/admin/Deactivate'}><Button className="col-md-12 btn-admin" variant="outline-warning">Deactivate user</Button></Link>
								<Link to={'/admin/Activate'}><Button className="col-md-12 btn-admin" variant="outline-warning">Activate user</Button></Link>
							
						</nav>
					</div>
					<div className="col-md-9 white-bg user-details">
					
					<Redirect  from="/admin" to="/admin/Adduser" />
					<Route  path = "/admin/Adduser" component = {Adduser}></Route>
					<Route  path = "/admin/Updateuser" component = {Updateuser}></Route>
					<Route  path = "/admin/Deactivate" component = {Deactivate}></Route>
					<Route  path = "/admin/Activate" component = {Activate}></Route>
					
					</div>
					<div class="clear"></div>
				</div>
			</div>
			</div>			
		</div>
		
    )
}
